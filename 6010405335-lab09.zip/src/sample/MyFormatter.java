package sample;

public interface MyFormatter {
    public String format(Object obj);
}
